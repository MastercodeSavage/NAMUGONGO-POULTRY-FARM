<?php
require 'views/partials/head.php';
?>
  <!-- head docunment ends there -->
<div class="container-fluid bg-img" >
  <h3 class="center-align Green-text darken-2">POULTY FARM NAMUGONGO</h3>
<div class="divider">

</div>
  <?php
  require 'views/partials/formlogin.php';
  ?>
<footer class="page-footer green">
  <div class="footer-copyright">
         <div class="container">
         © 2019 Copyright Mangeni Kenedy
         <a class="grey-text text-lighten-4 right" href="#!"><span class="flow-text"><i class="material-icons" >phone</i> +256 790442277<span></a>
         </div>
    </div>
</footer>
</div>
<?php
require 'views/partials/footer.php';
?>
<!-- footer of the  document -- and script files -->
