$(document).ready(function(){
  $('.sidenav').sidenav();
  $('.modal').modal();
   $('select').formSelect();
   $('textarea#textarea2').characterCounter();
     $('.datepicker').datepicker();


     $('.select').change(function(){
       var data = $('.select').val();

      $.post("../helper/products.php",{ elem : data },function(result){
         $('#details').html(result);
       });
      });
      $('#amount').keyup(function(){
        var select = $('#select').val();
        var data1 = $('#number_sold').val();
        $.post('stock.php',{elem : data1,elm2:select },function( result){
              $('.warn').html(result);
        });
      });



});
