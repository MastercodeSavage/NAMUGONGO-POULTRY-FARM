<?php
 include_once('database.php');

 class SystemApi{
   public $link;

   function __construct(){
     $connection = new dbconnection();
     $this->link = $connection->connect();
     return $this->link;
   }
  function sales($num,$product,$number_sold,$amount_collected,$balance_pending,$total,$date){
    $query = $this->link->prepare("INSERT INTO salerecord(entryno,product_id,number_sold,amount_collected,balance_pending,total,date) VALUES (?,?,?,?,?,?,?)");
    $parameters = array($num,$product,$number_sold,$amount_collected,$balance_pending,$total,$date);
    $query->execute($parameters);
    $count = $query->rowCount();
    return $count;
  }
  function fetchTable($tablename){
    $query = $this->link->query("SELECT *  FROM $tablename");
    $result = $query->fetchAll();
    return $result;
  }
  function Update($table,$data,$feildname,$where,$olddata){
    $query = $this->link->prepare("UPDATE  ? SET ? = ?   WHERE ?  = ? ");
    $values = array($table,$feildname,$data,$where ,$olddata);
    $query->execute($values);
    $count = $query->rowCount();
    return $count;
  }
  function selectWhere($table,$feildname,$target){
    $query = $this->link->prepare("SELECT *  FROM  :table WHERE :field = :target");
    $parameters = array(
      'table' => $table,
      'field' => $feildname,
      'target'=>$target
    );
      $query->execute($parameters);
      $result = $query->fetchObject();
    return $result;
  }
  function deletedata($id,$table,$value){
    $query = $this->link->prepare("DELETE * FROM ? WHERE ? = ?");
    $values = array($id,$table,$value);
    $query->execute($values);
    $count = $query->rowCount();
    return $count;
  }
  function joinquery($sql){
    $query = $this->link->query($sql);
    $result = $query->fetchAll();
    return $result;
  }
  function insertquery($sql){
    $query = $this->link->query($sql);
    if($query->rowCount() > 0 ){
      echo "<script>alert('successfully !');</script>";
    }
    else{
      echo "<script>alert('failed !');</script>";
    }
 }
}

?>
