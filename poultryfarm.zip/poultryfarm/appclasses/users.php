<?php
 include_once('database.php');
 class ManageUsers{
    public $link;

    function __construct(){
      $db_connection = new dbconnection();
      $this->link = $db_connection->connect();
      return $this->link;
    }
    function registerUser($useremail,$username,$password,$tell,$role){
      $query = $this->link->prepare('INSERT INTO users(user_id,user_name,password,tell,role) VALUES (?,?,?,?,?)');
      $values = array($useremail,$username,$password,$tell,$role );
      $query->execute($values);
      $count = $query->rowCount();
      return $count;
    }
    function loginValidate($username,$password){
      $query = $this->link->prepare('SELECT * FROM users WHERE user_id = ? AND password = ?');
      $values = array($username,$password);
     $query->execute($values);
     $count = $query->rowCount();
      return $count;
    }
    function fetchDetails($username){
      $query = $this->link->query("SELECT * FROM users WHERE user_id = '$username'");
      $rowcount = $query->rowCount();

      if($rowcount  == 1){
        $res =  $query->fetchAll();
        return $res;
      }
      else{
        return $rowcount;
      }

    }
    function Deleteuser($user_id){
      $query = $this->link->query("DELETE * FROM users WHERE user_id = $user_id");
      if($query){
        echo "<script>alert('User deleted successfuly ')</script>";
      }
    }


 }
//  $us = new ManageUsers();
//  $resb = $us->fetchDetails('wanderatimothy2@gmail.com');
// print_r($resb);
/*userapi working /*
 $user = new ManageUsers();
 echo $user->registerUser('wandera@code.com','mindz','67901890hj','0770112234','develop');
*/
?>
