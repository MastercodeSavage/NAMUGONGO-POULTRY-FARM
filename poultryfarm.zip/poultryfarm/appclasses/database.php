<?php
class dbconnection{
  public $hostname = 'localhost';
  public $password = '';
  public $username = 'root';
  public $database = 'poultry2';
  protected $conn;

  function connect(){
    try{
      $this->conn = new PDO("mysql:host=$this->hostname;dbname=$this->database",$this->username,$this->password);
      return $this->conn;
    }
    catch (PDOException $e){
      return $e->getMessage();
    }
  }
}

?>
