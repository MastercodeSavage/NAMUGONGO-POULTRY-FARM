<?php
include_once('../appScripts/session.php');
include_once('../appScripts/adminhamony.php');
 ?>

<?
require 'adminheader.php';
?>
 <div class="container-fluid">
   <nav class="nav-wrapper orange darken-4 accent-4">
     <a href="#" class="brand-logo right name" >Admin <?=$username;?></a>
  </nav>

<a  data-target="slide-out" class="btn pulse black darken-4 waves-effect btn-floating sidenav-trigger left"><i class="material-icons">menu</i></a>
</div>
<? require 'partials/adminsidenav.php'; ?>
<div class="row">
  <div class="col s12 m6 ">
    <div class="card">
      <div class="card-content">
        <span class="card-title">STOCK AVAILABLE</span>
        <table class=" highlight centered">
          <thead>
            <tr>
              <th>ITEM</th>
              <th>Number</th>
            </tr>
          </thead>
          <tbody>
              <? require '../helper/stock_records.php'; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <div class="col s12 m5">
    <div class="card">
      <div class="card-content">
        <span class="card-title">SET PRICES</span>
        <form  method="post">
          <div class="input-field ">
            <select id="select" name="product">
              <? require '../helper/getproduct.php';?>
            </select>
            <label>Select Product</label>
          </div>
          <div class="input-field">
            <input placeholder="10000" id="amount" type="number" required name="new_price" class="validate">
            <label for="amount">New Price (shs)</label>
          </div>
          <div class="input-field">
            <input type="submit" name="Change"  class="btn btn-large blue darken-4 align-center" id="enter">
          </div>
        </form>
          <a class="btn btn-sm orange darken-4" onclick="M.toast({html: 'Altering Prices May cause inconsistancies !'})">Warning!</a>
      </div>
      <? require '../helper/set_price.php' ?>
    </div>
  </div>
  
</div>





<? require 'foot.php';?>
