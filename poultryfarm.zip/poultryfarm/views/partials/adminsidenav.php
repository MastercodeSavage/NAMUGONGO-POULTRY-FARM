<ul id="slide-out" class="sidenav">
  <li>
    <div class="user-view">
      <div class="background">
        <img src="images/gd.jpeg" >
      </div>
        <a href="#user"><span class="circle"> <i class="material-icons">person</i> </span></a>
        <a href="#name"><span class="white-text name"><?=$username?></span></a>
        <a href="#email"><span class="white-text email"><?=$id?></span></a>
    </div>
  </li>
  <li> <div class="divider"></div> </li>
  <li> <a href="Dashboard1.php" class="waves-effect  orange-text darken-4"> <i class=" small orange-text material-icons">home</i>Home</a></li>
  <li> <div class="divider"></div> </li>
  <li> <a href="createEmployee.php" class="waves-effect  orange-text darken-4"><i class="  small orange-text material-icons">people</i>Workers </a> </li>
  <li> <div class="divider"></div> </li>
  <li> <a href="Cashbook.php" class="waves-effect  orange-text darken-4"><i class="  small orange-text  material-icons">book</i>Cashbook</a> </li>
  <li> <div class="divider"></div> </li>
  <li> <a href="aminchat.php" class="waves-effect  orange-text darken-4"><i class=" small orange-text  material-icons">message_bubble</i>Messages</a> </li>
  <li> <div class="divider"></div> </li>
  <li> <a href="../appScripts/logout.php" class="waves-effect  orange-text darken-4"><i class=" small orange-text  material-icons">exit_to_app</i>Sign out</a> </li>
</ul>


<!-- <script type="text/javascript">
  $(document).ready(function(){
    $('sidenav').sidenav();
  });
</script> -->
