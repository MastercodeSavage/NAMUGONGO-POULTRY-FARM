<ul id="slide-out" class="sidenav">
  <li>
    <div class="user-view">
      <div class="background">
        <img src="images/gd.jpeg" >
      </div>
        <a href="#user"><span class="circle"> <i class="material-icons">person</i> </span></a>
        <a href="#name"><span class="white-text name"><?=$username?></span></a>
        <a href="#email"><span class="white-text email"><?=$id?></span></a>
    </div>
  </li>
  <li> <div class="divider"></div> </li>
  <li> <a href="Employee.php" class="waves-effect  blue-text darken-4"> <i class=" small blue-text material-icons">home</i>Home</a></li>
  <li> <div class="divider"></div> </li>
  <li> <a href="Records.php" class="waves-effect  blue-text darken-4"><i class="  small blue-text material-icons">book</i> Records </a> </li>
  <li> <div class="divider"></div> </li>
  <!-- <li> <a href="employee_history.php" class="waves-effect  blue-text darken-4"><i class="  small blue-text  material-icons">history</i>History</a> </li>
  <li> <div class="divider"></div> </li> -->
  <li> <a href="chat.php" class="waves-effect  blue-text darken-4"><i class=" small blue-text  material-icons">message_bubble</i>Messages</a> </li>
  <li> <div class="divider"></div> </li>
  <li> <a href="../appScripts/logout.php" class="waves-effect  blue-text darken-4"><i class=" small blue-text  material-icons">exit_to_app</i>Sign out</a> </li>
</ul>


<!-- <script type="text/javascript">
  $(document).ready(function(){
    $('sidenav').sidenav();
  });
</script> -->
