<div class="container cntcontainer">
  <div class="row">
    <div class="col s9 m6 ofset-m6 ">
      <div class="card ">
        <span class="card-title">
          <h5 class="green-text lighten-2 accent-1 center-align lgp">Login</h5>
        <span>
          <div class="card-content">
            <form  method="post" id="formlogin">



              <div class="input-field ">
               <input placeholder="johndoe@user.com" id="user_email" type="email" class="validate" name="user_email">
               <label for="user_email">Email</label>
             </div>
             <div class="input-field ">
               <input placeholder="password" id="password" type="password" class="validate" name="password" required>
               <label for="password">Password</label>
             </div>
             <button class="btn waves-effect waves-light" type="submit" name="login">Submit
               <i class="material-icons right">send</i>
             </button>

            </form>

                <span>
                <a href="#" class="blue-text darken-4 fgp" style="font-size=11px;">forgot password</a>
                </span>
          </div>


      </div>
    </div>

  </div>

</div>
<? require 'appScripts/login.php'; ?>
<?php
  if(isset($error)){
 echo '<span class="red-text darken-4">'. $error.'</span>' ;
}
 ?>
