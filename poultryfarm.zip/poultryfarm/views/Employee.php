<?
include_once('../appScripts/session.php');
include_once('../appScripts/employeehamony.php');
require 'header.php';
?>
<div class="container-fluid">
  <nav class="nav-wrapper blue darken-4 accent-4">
    <a href="#" class="brand-logo right name" >Employee : <?=$username;?> </a>
  </nav>
  <a  data-target="slide-out" class="btn  blue darken-4 waves-effect btn-floating sidenav-trigger left"><i class="material-icons">menu</i></a>

<?
require 'partials/sidenav.php';
?>
<div class="container-fluid">
  <div class="row">
    <div class="col s12 m4  ">
      <div class="card">
        <div class="card-content">
          <form class method="post">
            <div class="input-field ">
              <select  class="select">
                <? require '../helper/getproduct.php';?>
              </select>
              <label>Select Product</label>
            </div>
            <div  id="details" class="details">
              <p >select product details will appear</p>
            </div>
          </form>
        </div>
      </div>
    </div>
    <div class="col s12 m6  ">
      <div class="card">
        <div class="card-content">
          <span class="card-title">Daily Record</span>
          <form class="" method="post">
            <div class="input-field ">
              <select id="select" name="product_id">
                <? require '../helper/getproduct.php';?>
              </select>
              <label>Select Product</label>
            </div>
            <div class="input-field">
              <input placeholder="Placeholder" id="number_sold" type="number" min="0" required name="num_sold" class="validate">
              <label for="number_sold">Number Sold</label>
              <p class=".warn"></p>
            </div>
            <div class="input-field">
              <input placeholder="Placeholder" id="amount" type="number" min="0" required name="amount_collected" class="validate">
              <label for="amount">Amount Collected (shs)</label>
            </div>
            <div class="input-field">
              <input placeholder="Placeholder" id="balance_pending" required type="number" name="balance" class="validate">
              <label for="balance_pending">Balance Pending (shs)</label>
            </div>
            <div class="input-field">
              <input placeholder="Placeholder" id="total" name="total" min="0"  required type="number" class="validate">
              <label for="balance_pending">Total (shs)</label>
            </div>
            <div class="input-field">
              <input placeholder="Placeholder" id="date_of_record"  required name="date_of_record" type="text" class="datepicker">
              <label for="balance_pending">Date</label>
            </div>
            <div class="input-field">
              <input type="submit" name="Enter"  class="btn btn-large blue darken-4 align-center" id="enter">
            </div>

          </form>

          <? require '../helper/submit_record.php'; ?>
        </div>
      </div>
    </div>

  </div>

</div>
</div>

<? require 'foot.php';?>
