<?
include_once('../appScripts/session.php');
include_once('../appScripts/employeehamony.php');
 require 'header.php'; ?>

<div class="container-fluid">
  <nav class="nav-wrapper blue darken-4 accent-4">
    <a href="#" class="brand-logo right name" >Employee <?=$username;?></a>
  </nav>
  <a  data-target="slide-out" class="btn  blue darken-4 waves-effect btn-floating sidenav-trigger left"><i class="material-icons">menu</i></a>

<?
require 'partials/sidenav.php';
?>

<div class="row">
  <div class="col s12 m8 push-m2">
    <div class="card">
      <div class="card-content">
        <span class="card-title">Update stock</span>
        <? require '../helper/getwhere.php';?>

          <? require '../helper/stock_update.php'; ?>
      </div>
    </div>
  </div>
</div>

</div>
<? require 'foot.php';?>
