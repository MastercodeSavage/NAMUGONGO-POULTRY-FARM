<?
include_once('../appScripts/session.php');
include_once('../appScripts/adminhamony.php');
require 'header.php';
?>
<div class="container-fluid">
  <nav class="nav-wrapper orange darken-4 accent-4">
    <a href="#" class="brand-logo right name" >Admin <?=$username;?></a>
 </nav>

<a  data-target="slide-out" class="btn pulse black darken-4 waves-effect btn-floating sidenav-trigger left"><i class="material-icons">menu</i></a>

<?
require 'partials/adminsidenav.php';
?>
<div class="row ">
  <div class="card col s12 m8 push-m2 ">
    <div class="card-content">
      <span class="card-title">
        <h3>Messages</h3>
      </span>
        <a class="btn-floating btn-large pulse  orange darken-4">@</a><?=$username?>
      <div class="messages">
        <? require '../helper/messages.php';?>

      </div>
    </div>
    <div class="card-action">
        <a href="#send_modal" class="btn btn-sm orange darken-4 waves-effect waves-light modal-trigger" >send</a>
    </div>
  </div>

</div>
</div>

<!-- modal markup -->
<div id="send_modal" class="modal  bottom-sheet">
    <div class="modal-content">
      <h4>Type your message</h4>
      <form  method="post">
        <div class="input-field">
          <textarea id="textarea2" class="materialize-textarea" data-length="120" name="message"></textarea>
          <label for="textarea2">Message</label>
        </div>

    </div>
    <div class="modal-footer">
      <button type="submit" name='send' class="btn btn-sm waves-effect orange darken-4 " ><i class="material-icons white-text right">send</i> Send</button>
    </div>
  </form>
  </div>
  <?require '../helper/message_sender.php';?>


<!-- ends here  -->
<? require 'foot.php';?>
