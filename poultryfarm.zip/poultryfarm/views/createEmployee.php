<?php
include_once('../appScripts/session.php');
include_once('../appScripts/adminhamony.php');
 ?>

<?
require 'adminheader.php';
?>
 <div class="container-fluid">
   <nav class="nav-wrapper orange darken-4 accent-4">
     <a href="#" class="brand-logo right name" >Admin <?=$username;?></a>
  </nav>

<a  data-target="slide-out" class="btn pulse black darken-4 waves-effect btn-floating sidenav-trigger left"><i class="material-icons">menu</i></a>
</div>
<? require 'partials/adminsidenav.php'; ?>
<div class="row">
  <div class="col s12 m6">
    <div class="card">
      <div class="card-content">
        <span class="card-title"><h4>System Users</h4></span>
        <table>
          <thead>
            <tr>
              <th>Username</th>
              <th>Email</th>
              <th>Tellephone</th>
              <th>Role</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <? require '../helper/users_api.php'; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <div class="col s12 m5">
    <div class="card">
      <div class="card-content">
        <span class="card-title">
          <h4>
            ADD USER
          </h4>
        </span>

      </div>
    </div>
  </div>
</div>




<? require 'foot.php';?>
