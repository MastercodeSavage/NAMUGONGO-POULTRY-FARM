<?php
if(isset($_POST['Enter'])){
  $product_id = $_POST['product_id'];
  $number_sold = $_POST['num_sold'];
  $amount_collected =$_POST['amount_collected'];
  $balance_pending = $_POST['balance'];
  $total = $_POST['total'];
  $date  = $_POST['date_of_record'];

  include_once('../appclasses/SystemApi.php');
  $Api = new SystemApi();

  if(empty($product_id) || empty($number_sold) || empty($amount_collected)  || empty($total) || empty($date)){
    echo "<script> alert all fields are required  ! </script>";
  }
  else{
    $data = $Api->joinquery("SELECT * FROM stock WHERE product_id = $product_id");
    foreach($data as $dt){
      $newstock = $dt['number'] - $number_sold;

      if(!($number_sold > $dt) ){
        $Api->sales(NULL,$product_id,$number_sold,$amount_collected,$balance_pending,$total,$date);
        $Api->insertquery("UPDATE stock SET number = $newstock ,dateofUpdate = CURRENT_TIMESTAMP WHERE product_id = $product_id");
        }
      else{
        echo "<script type='text/javascript'> First Update stock then comence </script>";
      }
    }


  }
}

?>
