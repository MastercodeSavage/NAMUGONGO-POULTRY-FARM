<?
if(isset($_GET[''])){
  $user_id = $_GET[''];
  include_once('../appclasses/users.php');
  $Api = new SystemApi();

  ?>
  <script type="text/javascript">
    let response = confirm("Are you sure about this action ?");
    if(response == true){

    }else{
      window.open('','_self');
    }
  </script>

  <?
  $Api->Deleteuser($user_id);
}

?>
