<?php
if(isset($_GET['product'])){
  include_once('../appclasses/SystemApi.php');
  $Api =  new SystemApi();
  $pro_id = $_GET['product'];
  $data = $Api->joinquery("SELECT  products.category_name, stock.number FROM products,stock WHERE stock.product_id = $pro_id AND stock.product_id = products.categoryid");
  foreach($data as $dt){
    $number = $dt['number'];
    $item = $dt['category_name'];

    ?>
  
    <form class="row"  method="post">
      <div class="input-field col-m3">
        <select name="product">
        <option value="<?=$pro_id;?>"><?=$item?></option>
        </select>
      </div>
      <div class="input-field col-m3">
        <input placeholder="Placeholder" id="number" type="number" min="0" required name="newAmount" value="<?=$number;?>" class="validate">
        <label for="number_sold">New Amount</label>
      </div>
      <div class="input-field">
        <input type="submit" name="update"  class="btn btn-large right blue darken-4 align-center" id="enter">
      </div>


    </form>



    <?
  }
}

?>
