<?php
  include_once('../appclasses/SystemApi.php');
  $api = new SystemApi();
  $sql = "SELECT products.categoryid,  products.category_name,stock.number FROM products,stock WHERE
          products.categoryid = stock.product_id";
  $data = $api->joinquery($sql);
  foreach ($data as $info) {
    $product_name = $info['category_name'];
    $number_available = $info['number'];
    $product_id = $info['categoryid'];

?>
  <tr>
    <td><?=$product_name;?></td>
    <td><?=$number_available;?></td>
    <td> <? if($role != 'admin'){  ?>
      <a href="Update_stock.php?product=<?=$product_id?>" class="btn btn-sm  ">Update</a>
        <?}?>
    </td>
  </tr>


<?

  }

?>
