<?php
if(isset($_POST['Change'])){
  $produt_id = $_POST['product'];
  $Price = $_POST['new_price'];
include_once('../appclasses/SystemApi.php');
$Api = new SystemApi();
 $sql ="UPDATE products SET pricePerProduct = $Price WHERE categoryid = $product_id";
 $count = $Api->insertquery($sql);
 echo "<script>window.reload();</script>";
}
?>
