<?php

if(isset($_POST['update'])){
  $product_id = $_POST['product_id'];
  $current_number = $_POST['update_value'];
  if(empty($product_id) || empty($current_number)){
    echo "<script>alert('all feilds are required');</script>";
  }
  else{
    include_once('../appclasses/SystemApi.php');
    $Api = new SystemApi();
    $date =("y-m-d");

    $update =$Api->Update('stock',$current_number,'number','product_id',$product_id);

    $update =$Api->Update('stock',$date,'date','product_id',$product_id);
  }
}

?>
