<?php
include_once('../appclasses/SystemApi.php');
$Api = new SystemApi();

$data = $Api->fetchTable('users');
foreach ($data as $info) {
  $username = $info['user_name'];
  $user_id = $info['user_id'];
  $role = $info['role'];

?>
<tr>
  <td><?=$username;?></td>
  <td><?=$user_id;?></td>
  <td><?=$info['tell'];?></td>
  <td><?=$role;?></td>
  <td>
    <? if($role != 'admin') {?>
    <a href="delete.php?id=<?=$user_id?>" class="btn btn-sm red darken-2"> Delete <i class="material-icons">delete_sweep</i></a>
    <?}?>
  </td>
</tr>
<?
}

?>
