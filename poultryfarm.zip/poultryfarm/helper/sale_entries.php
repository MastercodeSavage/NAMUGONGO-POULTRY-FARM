<?php
include_once('../appclasses/SystemApi.php');

$Api  =  new SystemApi();
$sql =  "SELECT  products.category_name,salerecord.entryno,salerecord.number_sold,salerecord.number_sold,
salerecord.amount_collected,salerecord.balance_pending,salerecord.Total,salerecord.date
FROM products , salerecord WHERE products.categoryid = salerecord.product_id ORDER BY salerecord.date";
$data = $Api->joinquery($sql);
foreach ($data as $val) {
  $product_id = $val['category_name'];
  $number_sold = $val['number_sold'];
  $amount_collected=$val['amount_collected'];
  $balance_pending=$val['balance_pending'];
  $total = $val['Total'];
  $date=$val['date'];

  ?>

  <tr>
        <td><?=$date?></td>
        <td><?=$product_id?></td>
        <td><?=$number_sold?></td>
        <td><?=$amount_collected?></td>
        <td><?=$balance_pending?></td>
        <td><?=$total?></td>
        <!-- <td>
          <a href="Edit.php?item=<?=$val['entryno']?>" class="btn btn-small ">edit<i class="material-icons">edit</i></a>
        </td> -->

  </tr>





  <?
}


?>
