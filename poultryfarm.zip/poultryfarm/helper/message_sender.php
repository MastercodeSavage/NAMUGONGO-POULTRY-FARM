<?php
if(isset($_POST['send'])){
  $message = $_POST['message'];
    if($_SESSION['role'] == 'admin'){
      $recipient = 'employee';
    }
    else
    {
      $recipient = 'admin';
    }
    $user_id = $_SESSION['user_id'];
    $date = date('Y-m-d');
  if(!empty($message)){
    include_once('../appclasses/SystemApi.php');
    $Api =  new SystemApi();
    $sql = "INSERT INTO messages(message_no,user_id,content,recipient,date)VALUES(NULL,'$user_id' ,'$message','$recipient',CURRENT_TIMESTAMP)";
    $Api->insertquery($sql);
    if($role == 'admin'){
      ?>
      <script type="text/javascript">
        window.open('aminchat.php','_self');
      </script>

      <?
    }else{
      ?>
      <script type="text/javascript">
        window.open('chat.php','_self');
      </script>

      <?
    }

  }
  else {
    echo "<script>Message cant be Empty</script>";
  }
}



?>
