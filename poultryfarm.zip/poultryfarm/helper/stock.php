<?php
$select_id = $_POST['elm2'];
$elm = $_POST['elm'];
include_once('../appclasses/SystemApi.php');
$api = new SystemApi();
$data = $api->joinquery("SELECT number FROM stock WHERE product = $select_id");
if($data > $elm ){
  echo "";
}
else
{
  echo "
      <span class='red-text darken-2'>Not enough stock for the transaction </span>
        ";
}




?>
