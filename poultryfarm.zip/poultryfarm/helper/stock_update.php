<?php

if(isset($_POST['update'])){

  $num = $_POST['newAmount'];
  $product = $_POST['product'];
  if(!empty($num) && !empty($product)){
      include_once('../appclasses/SystemApi.php');
      $Api = new SystemApi();
      $Api->insertquery("UPDATE stock SET number = $num , dateofUpdate = CURRENT_TIMESTAMP WHERE product_id = $product");

      ?>
      <script type="text/javascript">
        window.open('Records.php','_self');
      </script>

      <?
  }


}



?>
