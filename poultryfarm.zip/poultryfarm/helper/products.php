<?php

  $elm = $_POST['elem'];
  if(!empty($elm)){
  include_once('../appclasses/SystemApi.php');
  $sql ="SELECT  stock.number ,products.pricePerProduct FROM stock ,products  WHERE  stock.product_id = $elm AND products.categoryid ";
  $api = new SystemApi();
  $data = $api->joinquery($sql);
  foreach ($data as $row) {
    $product =  $row['number'];
    $price = $row['pricePerProduct'];
  }

   ?>
   <span class="card-title"><?=$product?> Available</span>
   <div class="divider"></div>
   <span class="card-title"><?=$price?>(shs) each</span>

   <?
 }

else{
   ?>
     <span class="card-title">No Details</span>
      <?
}
