<?php

include_once('../appclasses/SystemApi.php');
$sql = "SELECT users.user_name,messages.message_no,messages.content,messages.recipient,messages.date FROM users , messages WHERE users.user_id = messages.user_id  ORDER BY message_no DESC  ";
$api = new SystemApi();
$data = $api->joinquery($sql);
$count = 0;
foreach ($data as  $msg) {
  $count++;
  $sender = $msg['user_name'];
  $recipient = $msg['recipient'];
  $content= $msg['content'];
  $time = $msg['date'];
  if($count == 6){
    break;
  }
  ?>
    <div>
      <span><? if( $role != $recipient) { echo "ME ::>>";} else {echo $sender."::>>"; }?></span>
      <span><?=$time;?></span>
      <p class="flow-text"><?=$content?></p>
    </div>
    <div class="divider"></div>
  <?
}


?>
