<option value="" disabled selected>Choose your option</option>
<?php
include_once('../appclasses/SystemApi.php');
$request = new SystemApi();
$data = $request->fetchTable('products');
foreach ($data as $info) {
  $name = $info['category_name'];
  $price = $info['pricePerProduct'];
  $product_id = $info['categoryid'];

?>
<option value="<?php echo $product_id;?>"> <?php echo $name;?></option>
<?php
}
?>
