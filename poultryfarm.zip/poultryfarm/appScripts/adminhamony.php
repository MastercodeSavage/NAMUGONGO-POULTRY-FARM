<?
if($role === 'admin'){

}
else {
  session_destroy();
  header('Location : ../index.php');
}
?>
