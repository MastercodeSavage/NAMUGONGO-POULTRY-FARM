<?php
session_start();
if(isset($_SESSION['role'])){
  $username = $_SESSION['user_name'];
  $id = $_SESSION['user_id'];
  $role = $_SESSION['role'];

}else{
  header('Location:../index.php');
}

?>
