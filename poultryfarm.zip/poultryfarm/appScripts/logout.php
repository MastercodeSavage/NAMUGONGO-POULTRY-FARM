<?php
session_start();
 session_destroy();
?>
<script type="text/javascript">
window.open('../index.php','_self');
</script>
