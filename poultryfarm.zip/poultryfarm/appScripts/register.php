<?php

if(isset($_POST['register'])){
  include_once('../appclasses/users.php');
   $user = new ManageUsers();

  $useremail = $_POST['user_email'];
  $username = $_POST['user_name'];
  $password = $_POST['password'];
  $repassword = $_POST['repassword'];
  $role = $_POST['role'];
  $tel = $_POST['tell'];

  if(empty($useremail) || $empty($password) || empty($username) || empty($role)  || empty($tell)){
    $error = 'All Feilds are required';
  }
  elseif( $password != $repassword){
    $error = 'Passwords do not match';
  }
  elseif(!filter_var($useremail,FILTER_VALIDATE_EMAIL)){
    $error = 'Invalid Email';
  }
  else {
    $checkavailability = $user->fetchDetails($username);
    if($checkavailability == 1){
      $error = 'username already taken';
    }
    else{
     $reguser =   $user->registerUser($useremail,$username,$password,$role,$tel);
     $session_info  = $user->fetchDetails($username);
     foreach ($session_info as $sess){
       session_start();
       $_SESSION['user_name'] = $sess['user_name']
      $_SESSION['user_role'] = $sess['role'];

      header('Location: ../views/Dashboard.php');
     };
    }
  }
}

?>
