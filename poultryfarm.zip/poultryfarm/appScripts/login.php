<?php
  if(isset($_POST['login'])){

    $useremail = $_POST['user_email'];
    $password = $_POST['password'];


    include_once('appclasses/users.php');

    $user  = new ManageUsers();
    if(empty($useremail) || empty($password)){

       $error = "All feilds are required";
    }
    else{
      $count = $user->loginValidate($useremail,$password);
      if($count == 1){
        echo "<script> alert('page note found ghu')</script>";
        $session_info = $user->fetchDetails($useremail);
        foreach($session_info as $info){
          session_start();
          $_SESSION['user_id'] = $info['user_id'];
          $_SESSION['user_name'] = $info['user_name'];
          $_SESSION['role'] = $info['role'];
          if($_SESSION['role'] == 'admin'){

            header('Location:views/Dashboard1.php');
          }
          elseif($_SESSION['role'] == 'employee') {

            header('Location:views/Employee.php');
          }
          else{
            $error="page not found";
            echo "<script> alert('page note found')</script>";
            header('Location:views/404.php?$error='.$error);

          }
        }
      }
    }


  }

?>
